https://www.playonloop.com/

   ___ _               ___         __                   
  / _ \ | __ _ _   _  /___\_ __   / /  ___   ___  _ __  
 / /_)/ |/ _` | | | |//  // '_ \ / /  / _ \ / _ \| '_ \ 
/ ___/| | (_| | |_| / \_//| | | / /__| (_) | (_) | |_) |
\/    |_|\__,_|\__, \___/ |_| |_\____/\___/ \___/| .__/ 
               |___/                             |_|    


PlayOnLoop was launched in 2010 as one of the first Royalty-free music loops sites with a wide variety of music genres and mood and plenty of downloadable freebies added every month. Since then PlayOnloop has continued its growth as one of the most affordable and original music libraries around with a wide fanbase that loves the music and the friendly customer support, and finally in 2020 a new category dedicated to Sound Effects has been introduced.

-=== Sound Effects usage and License ===-

Our Sound Effects are licensed under Creative Commons: By Attribution 4.0. To use this license, simply attribute the sound effects you're using in your creation (videogame, app, website, film, phone system, etc.) as is reasonable to the medium. 

If you can't credit us or just don’t want to indicate the source, we ask for a little donation – you can donate as much as you want. To make things easier for you, we have a Ko-fi page where you can donate using PayPal or Stripe, and can decide if making your donation private.If you can't credit us, please consider a donation to our Ko-fi page: https://ko-fi.com/playonloop

-=== How to get Support? ===-

Just write to info@playonloop.com! Customers who have bought our Royalty-free Music will receive priority handling and a guaranteed response. Limited after hours and weekend/holiday support is not guarateed. Please do not send the same request more than once.

-== Other ==-

Please check the website FAQ section, you will find very important information about PlayOnLoop, music and sounds usage and other common questions answered. Also, do not miss PlayOnLoop on the most popular Social Network out there.

Thanks for downloading Sound Effects from PlayOnLoop!

Filippo Vicarelli
Founder and Music Producer at PlayOnLoop.com
https://www.playonloop.com/

--
Readme v.1.2 - March 2020